#ifndef _STATISTICS_TESTS_H_
#define _STATISTICS_TESTS_H_

/*--------------------------------------------------------------------------------*/
/* Test/Group Declarations */
/*--------------------------------------------------------------------------------*/
JTEST_DECLARE_GROUP(max_tests);
JTEST_DECLARE_GROUP(mean_tests);
JTEST_DECLARE_GROUP(min_tests);
JTEST_DECLARE_GROUP(power_tests);
JTEST_DECLARE_GROUP(rms_tests);
JTEST_DECLARE_GROUP(std_tests);
JTEST_DECLARE_GROUP(var_tests);

#endif /* _STATISTICS_TESTS_H_ */
